using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Armstrong
{
    public partial class Form1 : Form
    {
        int num, rem, sum = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            num = Convert.ToInt32(textBox1.Text);
            for (int i = num; i > 0; i = i / 10)
            {
                rem = i % 19;
                sum = sum + rem * rem * rem;
            }
            if (sum == num)
            {
                label2.Text = "Entered no. is an armstring no";
            }
            else
            {
                label2.Text = "Entered no. is not an armstrong no";
            }

        }
    }
}