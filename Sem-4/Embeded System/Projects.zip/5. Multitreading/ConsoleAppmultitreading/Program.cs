using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ConsoleAppmultitreading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MultiThreading");
            Thread tid1 = new Thread(new ThreadStart(MyThread.Thread1));
            Thread tid2 = new Thread(new ThreadStart(MyThread.Thread2));
            tid1.Start();
            tid2.Start();
        }
    }
            public class MyThread
    {
        public static void Thread1()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Thread1{0}", i);

            }
        }
        public static void Thread2()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Thread2 {0}", i);
                Console.ReadLine();
            }
        }

        }
    }
