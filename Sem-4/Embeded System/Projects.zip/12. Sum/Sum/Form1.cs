using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Sum
{
    public partial class Form1 : Form
    {
        int n, sum = 0, m;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            m = n % 10;
            sum = sum + m;
            n = n / 10;
            label2.Text = "sum of Digit =" + sum;
        }
    }
}