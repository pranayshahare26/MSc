using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace mouseevent
{
    public partial class Form1 : Form
    {
        int x, y;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_ParentChanged(object sender, EventArgs e)
        {

        }
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            x = MousePosition.X;
            y = MousePosition.Y;
            lblmessage.Text = "MOUSE DOWN EVENT OCCURED POSITION:" + x + "" + y;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            x = MousePosition.X;
            y = MousePosition.Y;
            lblmessage.Text = "MOUSE MOVE EVENT OCCURED POSITION:" + x + "" + y;

        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            x = MousePosition.X;
            y = MousePosition.Y;
            lblmessage.Text = "MOUSE UP EVENT OCCURED POSITION:" + x + "" + y;

        }

    }
}