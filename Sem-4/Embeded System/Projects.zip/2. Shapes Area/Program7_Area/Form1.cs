using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Program7_Area
{
    public partial class Form1 : Form
    {
        Single hei, bs, rad, wid, hi, sid;
        int num;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void menuItem2_Click(object sender, EventArgs e)
        {
            num = 1;
            lblHeight.Visible = true;
            lblBase.Visible = true;
            txtHeight.Visible = true;
            txtBase.Visible = true;
            txtHeight.Text = "";
            txtBase.Text = "";
            txtArea.Text = "";
            txtHeight.Focus();
        }

        private void menuItem3_Click(object sender, EventArgs e)
        {
            num = 2;
            lblHeight.Visible = true;
            lblHeight.Text = "width";
            lblBase.Visible = true;
            lblBase.Text = "height";
            txtHeight.Visible = true;
            txtBase.Visible = true;
            txtHeight.Text = "";
            txtBase.Text = "";
            txtArea.Text = "";
            txtHeight.Focus();
        }

        private void menuItem4_Click(object sender, EventArgs e)
        {
            num = 3;
            lblHeight.Visible = true;
            lblHeight.Text = "Radius";
            lblBase.Visible = false;
            lblHeight.Visible = true;
            txtHeight.Visible = true;
            txtBase.Visible = false;
            txtHeight.Text = "";
            txtBase.Text = "";
            txtArea.Text = "";
            txtHeight.Focus();
        }

        private void menuItem5_Click(object sender, EventArgs e)
        {
            num = 4;
            lblHeight.Visible = true;
            lblHeight.Text = "side";
            // lblHeight.Visible=true;
            txtHeight.Visible = true;
            //txtBase.Visible=false;
            txtHeight.Text = "";
            //txtBase.Text="";
            txtArea.Text = "";
            txtHeight.Focus();
        }

        private void menuItem6_Click(object sender, EventArgs e)
        {
            switch(num)
            {
                case 1:
                    bs=Convert.ToSingle(txtBase.Text);
                    hei= Convert.ToSingle(txtHeight.Text);
                    txtArea.Text=(0.5*bs*hei).ToString();
                    break;
                case 3:
                    rad = Convert.ToSingle(txtHeight.Text);
                    //hei = Convert.ToSingle(txtHeight.Text);
                    txtArea.Text = (Math.PI*rad*rad).ToString();
                    break;
                case 4:
                    sid=Convert.ToSingle(txtHeight.Text);
                    txtArea.Text = (sid * sid).ToString();
                    break;
                case 2:
                    wid = Convert.ToSingle(txtBase.Text);
                    hi= Convert.ToSingle(txtHeight.Text);
                    txtArea.Text=(wid*hei).ToString();
                    break;
                default:
                    txtArea.Text="";
                    break;
            }
        }

    }
}