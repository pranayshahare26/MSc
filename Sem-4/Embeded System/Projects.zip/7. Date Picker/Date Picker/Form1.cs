using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Date_Picker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime curTime = DateTime.Now;
            int yr, month, day;
            DateTime bday;
            bday = Convert.ToDateTime(dateTimePicker1.Value);
            month = 12 * (DateTime.Now.Year - bday.Year) + (DateTime.Now.Month - bday.Month);
            if (DateTime.Now.Day < bday.Day)
            {
                month -= 1;
                day = DateTime.DaysInMonth(bday.Year, bday.Month) - bday.Day + DateTime.Now.Day;
            }
            else
            {
                day = DateTime.Now.Day - bday.Day;
            }
            yr = Convert.ToInt32(Math.Floor(month / 12));

            month -= yr * 12;
            label2.Text = yr + "year" + month + "Month" + day + "Days";
        }
        }
    }