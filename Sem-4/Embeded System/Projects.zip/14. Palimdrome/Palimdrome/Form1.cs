using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Palimdrome
{
    public partial class Form1 : Form
    {
        int num, rem, sum = 0, temp;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            num = Convert.ToInt32(textBox1.Text);
            temp = num;
            while (num > 0)
            {
                rem = num % 10;
                num = num / 10;
                sum = sum * 10 + rem;
            }
            label2.Text = "The Reversed Number is :" + sum;
            if (temp == sum)
            {
                label3.Text = "The Number is Palindrome";
            }
            else
            {
                label3.Text = "The Number is Not Palindrome";
            }
        }
    }
}