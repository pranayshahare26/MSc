using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Marksheet
{
    public partial class Form1 : Form
    {
        int r, m1, m2, m3, t;
        float p;
        string n;
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_ParentChanged(object sender, EventArgs e)
        {

        }

        private void label4_ParentChanged(object sender, EventArgs e)
        {

        }

        private void label2_ParentChanged(object sender, EventArgs e)
        {

        }

        private void label7_ParentChanged(object sender, EventArgs e)
        {

        }

        private void label5_ParentChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            r = Convert.ToInt32(textBox1.Text);
            n = Convert.ToString(textBox2.Text);
            m1 = Convert.ToInt32(textBox3.Text);
            m2 = Convert.ToInt32(textBox4.Text);
            m3 = Convert.ToInt32(textBox5.Text);
            t = m1 + m2 + m3;
            p = t / 3.0f;
            label6.Text = "Total is : " + t;
            label7.Text = "Percentage is : " + p;
        }
    }
}