using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Prefix
{
    public partial class Form1 : Form
    {
        int x;
        int[] y = new int[10];
        int i;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            x = 1;
            for (i = 0; i < 10; i++)
            {
                y[i] = x + ++x;
            }
            txtprefix.Text = y[0] + " " + y[1] + " " + y[2] + " " + y[3] + " " + y[4] + " " + y[5] + " " + y[6] + " " + y[7] + " " + y[8] + " " + y[9] + " "; 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            x = 1;
            for (i = 0; i < 10; i++)
            {
                y[i] = x + (x++);
            }
            txtpostfix.Text = y[0] + " " + y[1] + " " + y[2] + " " + y[3] + " " + y[4] + " " + y[5] + " " + y[6] + " " + y[7] + " " + y[8] + " " + y[9] + " "; 
        }
    }
}