using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Image_Viewer
{
    public partial class Form1 : Form
    {
        int inc = 0;
        int count = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
                        count = imageList.Images.Count - 1;
            pictureBox.Image = imageList.Images[0];
            inc++;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        
        }

        private void menuItem_Click(object sender, EventArgs e)
        {
                        if (inc >= 0)
            {
                if (inc == count)
                    inc--;
                pictureBox.Image = imageList.Images[inc];
                if (inc == 0)
                    inc = 0;
                else
                    inc--;
                        }
        }

        private void menuItem2_Click(object sender, EventArgs e)
        {
                        if (inc <= count)
            {
                if (inc == 0)
                    inc++;
            }
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            pictureBox.Image = imageList.Images[inc];
            if (inc == count)
                inc = count;
            else
                inc++;
        }
    }
}