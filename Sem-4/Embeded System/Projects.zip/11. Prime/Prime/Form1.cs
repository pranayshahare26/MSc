using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Prime
{
    public partial class Form1 : Form
    {
        int num, k = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
                       num = Convert.ToInt32(textBox1.Text);
           for (int i = 1; i <= num; i++)
           {
               if (num % i == 0)
               {
                   k++;
               }

           }
           if (k == 2)
           {
               label2.Text = "Entered no is prime no ";
           }
           else
           {
               label2.Text = "Entered no is not prime no";
           }
        }
    }
}