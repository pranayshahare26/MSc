namespace Current_Time
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.textBox = new System.Windows.Forms.TextBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lblcou = new System.Windows.Forms.Label();
            this.lblres = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(148, 4);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(100, 21);
            this.textBox.TabIndex = 4;
            this.textBox.Text = "22:15";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(3, 3);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(136, 22);
            this.dateTimePicker.TabIndex = 5;
            // 
            // comboBox1
            // 
            this.comboBox1.Items.Add("Australia");
            this.comboBox1.Items.Add("Bhutan");
            this.comboBox1.Items.Add("Canada");
            this.comboBox1.Items.Add("China");
            this.comboBox1.Items.Add("France");
            this.comboBox1.Items.Add("Nepal");
            this.comboBox1.Items.Add("Pakistan");
            this.comboBox1.Location = new System.Drawing.Point(4, 55);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 22);
            this.comboBox1.TabIndex = 6;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lblcou
            // 
            this.lblcou.Location = new System.Drawing.Point(4, 101);
            this.lblcou.Name = "lblcou";
            this.lblcou.Size = new System.Drawing.Size(100, 20);
            this.lblcou.ParentChanged += new System.EventHandler(this.lblcou_ParentChanged);
            // 
            // lblres
            // 
            this.lblres.Location = new System.Drawing.Point(4, 154);
            this.lblres.Name = "lblres";
            this.lblres.Size = new System.Drawing.Size(100, 20);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.lblres);
            this.Controls.Add(this.lblcou);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.textBox);
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lblcou;
        private System.Windows.Forms.Label lblres;
    }
}

