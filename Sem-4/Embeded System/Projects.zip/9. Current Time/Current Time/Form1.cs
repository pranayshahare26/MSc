using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Current_Time
{
    public partial class Form1 : Form
    {
        DateTime da;
        DateTime dt = new DateTime();
        DateTime dat;
        int hr;
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_ParentChanged(object sender, EventArgs e)
        {

        }

        private void label1_ParentChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((textBox.Text == "22:15"))
            {
                dat = Convert.ToDateTime(dateTimePicker.Value);
                da = Convert.ToDateTime(textBox.Text);
                hr = da.Hour;
                if (comboBox1.SelectedIndex == 0)
                {
                    dt = da.AddHours(4).AddMinutes(30);
                    lblcou.Text = "Australia";
                    funnext();
                }
                if (comboBox1.SelectedIndex == 1)
                {
                    dt = da.AddHours(4).AddMinutes(30);
                    lblcou.Text = "Bhutan";
                    funnext();
                }
                if (comboBox1.SelectedIndex == 2)
                {
                    dt = da.AddHours(4).AddMinutes(30);
                    lblcou.Text = "Canada";
                    funbac();
                }
                if (comboBox1.SelectedIndex == 3)
                {
                    dt = da.AddHours(4).AddMinutes(30);
                    lblcou.Text = "China";
                    funnext();
                }
                if (comboBox1.SelectedIndex == 4)
                {
                    dt = da.AddHours(4).AddMinutes(30);
                    lblcou.Text = "France";
                    funbac();
                }
                if (comboBox1.SelectedIndex == 5)
                {
                    dt = da.AddHours(0).AddMinutes(15);
                    lblcou.Text = "Nepal";
                    funnext();
                }
                if (comboBox1.SelectedIndex == 6)
                {
                    dt = da.AddHours(0).AddMinutes(30);
                    lblcou.Text = "Pakistan";
                    funbac();
                }
                lblres.Text = "";
                string str = dat.Month + "/" + dat.Day + "/" + dat.Year;
                str = str + " " + dt.Hour.ToString() + ":" + dt.Minute.ToString();
                lblres.Text = str;
            }
            else
                textBox.Text = "";
        }
        public void funnext()
        {
            int a;
            if (dt.Hour > hr)
                a = dt.Hour - hr;
            else
                a = dt.Hour;
            hr = hr + a;
            if (hr >= 24)
                dat = dat.AddDays(1);
        }
        public void funbac()
        {
            hr = hr - dt.Hour;
            if (hr < 0)
                dat = dat.AddDays(-1);
        }

        private void lblcou_ParentChanged(object sender, EventArgs e)
        {

        }
    }
}