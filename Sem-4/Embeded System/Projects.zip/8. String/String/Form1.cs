using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace String
{
        public delegate string strDelegate(string s);
    public partial class Form1 : Form
    {
        strDelegate sd;
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_ParentChanged(object sender, EventArgs e)
        {

        }

        private void lowerBtn_Click(object sender, EventArgs e)
        {
            sd = new strDelegate(DelegateEx.AllChrLowerCAse);
            label3.Text = sd.Invoke(textBox1.Text);
            label2.Text = "LowerCase";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sd = new strDelegate(DelegateEx.StrReverse);
            label3.Text = sd.Invoke(textBox1.Text);
            label2.Text = "Reverse String";
        }

        private void uppercaseBtn_Click(object sender, EventArgs e)
        {
            sd = new strDelegate(DelegateEx.AllChrUpperCAse);
            label3.Text = sd.Invoke(textBox1.Text);
            label2.Text = "UpperCase";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            sd = new strDelegate(DelegateEx.Encrypt);
            label3.Text = sd.Invoke(textBox1.Text);
            label2.Text = "Encrypted String";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            sd = new strDelegate(DelegateEx.strremovespace);
            label3.Text = sd.Invoke(textBox1.Text);
            label2.Text = "After Removing Space";
        }
    }
    class DelegateEx
    {
        public static string AllChrLowerCAse(string s)
        {
            string lower = s.ToLower();
            return lower;
        }
        public static string AllChrUpperCAse(string s)
        {
            string upper = s.ToUpper();
            return upper;
        }
        public static string StrReverse(string s)
        {
            int len = s.Length;
            char[] arr = new char[len];
            for (int i = 0; i < len; i++)
            {
                arr[i] = s[len - 1 - i];

            }
            return new string(arr);
        }
        public static string Encrypt(string s)
        {
            int len = s.Length, i = 0;
            char[] str = new char[len];
            string str1 = "";
            while (i < len)
            {
                if (string.Compare(s[i].ToString(), str1) != 0)
                    str[i] = Convert.ToChar(Convert.ToInt32(s[i] + 100));
                else
                    str[i] = ' ';
                i++;
            }
            return new string(str);
        }
        public static string strremovespace(string s)
        {
            int len = s.Length, i = 0, j = 0;
            char[] str = new char[len];
            string str1 = " ";
            while (i < len)
            {
                if (string.Compare(s[i].ToString(), str1) != 0)
                {
                    str[j] = s[i];
                    j++;
                }
                i++;
            }
            return new string(str);
        }

    }
}