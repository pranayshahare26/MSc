namespace String
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lowerBtn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.uppercaseBtn = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(67, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 20);
            this.label1.Text = "Format of String";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(4, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.Text = "String";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(4, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(4, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 20);
            this.label4.ParentChanged += new System.EventHandler(this.label4_ParentChanged);
            // 
            // lowerBtn
            // 
            this.lowerBtn.Location = new System.Drawing.Point(14, 120);
            this.lowerBtn.Name = "lowerBtn";
            this.lowerBtn.Size = new System.Drawing.Size(90, 20);
            this.lowerBtn.TabIndex = 4;
            this.lowerBtn.Text = "Lower Case";
            this.lowerBtn.Click += new System.EventHandler(this.lowerBtn_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(128, 120);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 20);
            this.button2.TabIndex = 5;
            this.button2.Text = "Reverse";
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // uppercaseBtn
            // 
            this.uppercaseBtn.Location = new System.Drawing.Point(14, 180);
            this.uppercaseBtn.Name = "uppercaseBtn";
            this.uppercaseBtn.Size = new System.Drawing.Size(90, 20);
            this.uppercaseBtn.TabIndex = 6;
            this.uppercaseBtn.Text = "Upper Case";
            this.uppercaseBtn.Click += new System.EventHandler(this.uppercaseBtn_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(128, 180);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(89, 20);
            this.button4.TabIndex = 7;
            this.button4.Text = "Encrypt";
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(67, 227);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(87, 20);
            this.button5.TabIndex = 8;
            this.button5.Text = "Remove Spave";
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(110, 34);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.uppercaseBtn);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.lowerBtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button lowerBtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button uppercaseBtn;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox1;
    }
}

